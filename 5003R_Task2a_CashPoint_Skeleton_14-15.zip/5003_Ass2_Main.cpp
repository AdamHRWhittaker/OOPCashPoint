//Pascale Vacher - March 15
//OOP Assignment Semester 2

#include "CashPoint.h"         //include modules header files

//---------------------------------------------------------------------------

//main application

int main() { 
	//create the application
	CashPoint theCashPoint;
    //run it
	theCashPoint.activateCashPoint();
	//destroy it
	//destructor called here
    return 0;
}
